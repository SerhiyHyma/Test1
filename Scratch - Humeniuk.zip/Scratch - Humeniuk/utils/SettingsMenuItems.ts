export const Language: number = 1;
export const Color_Mode: number = 2;