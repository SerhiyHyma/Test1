import * as fs from 'fs';
import * as path from 'path';
import { PNG } from 'pngjs';
import { Page, PageScreenshotOptions } from 'playwright';
import pixelmatch from 'pixelmatch';

export class ImageComparison {
    static async captureScreenshot(page: Page, filePath: string, options?: PageScreenshotOptions) {
        await page.screenshot({ path: filePath, ...options });
    };

    static compareImages(imagePath1: string, imagePath2: string): boolean {
        const img1 = PNG.sync.read(fs.readFileSync(imagePath1));
        const img2 = PNG.sync.read(fs.readFileSync(imagePath2));

        const { width, height } = img1;
        const diff = new PNG({ width, height });

        const mismatchedPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.7 });

        fs.writeFileSync('diff.png', PNG.sync.write(diff));

        return mismatchedPixels === 0;
    };

    static generateDiffImage(image1: string, image2: string, outputPath: string): void {
        const img1 = PNG.sync.read(image1);
        const img2 = PNG.sync.read(image2);
        
        const { width, height } = img1;
        const diff = new PNG({ width, height });

        pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.7 });

        fs.writeFileSync(outputPath, PNG.sync.write(diff));
    };
}