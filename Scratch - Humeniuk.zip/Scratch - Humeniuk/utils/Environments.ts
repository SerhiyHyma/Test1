export default class Environments {
    public static qaEnv: string = "https://scratch.mit.edu/";
    public static createPageQa: string = "https://scratch.mit.edu/projects/editor/?tutorial=getStarted";
}