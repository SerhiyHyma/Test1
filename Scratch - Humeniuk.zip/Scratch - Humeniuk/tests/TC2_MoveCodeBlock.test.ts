import { Browser, BrowserContext, Page, test, expect, chromium } from "@playwright/test";
import Environments from "../utils/environments";
import CreatePage from "../page/Create.page";

test.describe("TC2 Move Code Block", () => {
    let browser: Browser;
    let context: BrowserContext;
    let page: Page;

    let createPage: CreatePage;


    test.beforeAll(async() => {
        test.setTimeout(60000);
        browser = await chromium.launch();
        context = await browser.newContext();
        page = await context.newPage();
        await page.goto(Environments.createPageQa);
        
        createPage = new CreatePage(page);
    });

    test.afterAll(async () => {
        await page.close();
        await context.close();
        await browser.close();
    });

    test("Check that block of code can be moved to Constructor area", async() => {
        await createPage.waitForStartFlag();
        await createPage.closeTutorialVideo();
        await createPage.moveCodeBlock();
        await createPage.waitForBlockInConstructArea();
        
        expect(await createPage.isBlockInDropArea()).toBe(true);
    });
})