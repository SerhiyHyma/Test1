import { Browser, BrowserContext, Page, test, expect, chromium } from "@playwright/test";
import Environments from "../utils/environments";
import CreatePage from "../page/Create.page";
import { Language } from "../utils/SettingsMenuItems";
import { Turkish } from "../utils/LanguagesInMenu";

test.describe("TC3 Change Language", () => {
    let browser: Browser;
    let context: BrowserContext;
    let page: Page;

    let createPage: CreatePage;


    test.beforeAll(async() => {
        test.setTimeout(60000);
        browser = await chromium.launch();
        context = await browser.newContext();
        page = await context.newPage();
        await page.goto(Environments.createPageQa);
        
        createPage = new CreatePage(page);
    });

    test.afterAll(async () => {
        await page.close();
        await context.close();
        await browser.close();
    });

    test("Check menu language can be changed", async() => {
        await createPage.waitForStartFlag();
        await createPage.openSettingsDropDown();
        await createPage.selectSettingsSubMenu(Language);
        
        const initialTitle: string | null = await createPage.getSettingTitle();
        await createPage.selectLanguage(Turkish);

        const changedTitle: string | null = await createPage.getSettingTitle();
        
        expect(initialTitle).not.toBe(changedTitle); 
    });
})