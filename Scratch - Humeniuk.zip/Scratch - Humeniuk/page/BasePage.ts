import { Locator, Page } from "playwright";

export default abstract class BasePage {

    private page: Page;

    constructor(page: Page) {
        this.page = page
    }

    public async getUrl(): Promise<string> {
		return this.page.url()
	}

    public async isElementVisible(selector: string, errorMessage: string): Promise<boolean> {
		const element = this.page.locator(selector)
		try {
			const isVisible = await element.isVisible()
			return isVisible;
		} catch (error) {
			throw new Error(`${errorMessage}`)
		}
	}

    async isElementEnabled(selector: Locator, errorMessage: string): Promise<boolean> {
		try {
			const isEnabled = await selector.isEnabled()
			return isEnabled;
		} catch (error) {
			throw new Error(`${errorMessage}`)
		}
	}

    findLocator(selector: string): Locator {
        return this.page.locator(selector);
    }

    async isButtonDisabled(button: Locator): Promise<boolean> {
        return await button.evaluate((element: HTMLButtonElement) => element.disabled);
    }

    async elementShouldBeVisible(element: string): Promise<void> {
        await this.findLocator(element).waitFor({state: 'visible'});
    }

    async isEnabled(element: string): Promise<void> {
        await this.findLocator(element).isEnabled();
    }

    async dragAndDrop(source: string, target: string): Promise<void> {
        await this.page.dragAndDrop(source, target);
    }

    async clickOnElement(element: string): Promise<void> {
        await this.findLocator(element).click();
    }

    async getTitle(element: string): Promise<string | null> {
        const title = this.findLocator(element).textContent();
        return title;
    }
}