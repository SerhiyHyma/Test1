import { Locator, Page } from "@playwright/test";
import BasePage from "./BasePage";

export default class CreatePage extends BasePage {

    private startFlagButton = "//div[@class='controls_controls-container_2xinB']";
    private closeTutorialVideoBtn = "//img[@class='card_close-icon_1FYf5']";
    private blockOfCode = "g[data-id='motion_movesteps']";
    private constructorArea = "rect[class='blocklyMainBackground']";
    private blockOfCodeInConstructorArea = ".blocklyBlockCanvas .blocklyDraggable.blocklySelected";
    private settingsButton = "//span[@class='settings-menu_dropdown-label_3f68c']";
    private editButton = "//div[4]/span[@class='menu-bar_collapsible-label_o2tym']";
    private languages = "//li[contains(@class, 'menu_menu-item_3EwYA')]";
    private turboModeLable = "//div[contains(@class, 'turbo-label')]"

    
    constructor(page: Page) {
        super(page);
    }

    async waitForStartFlag(): Promise<void> {
        await this.elementShouldBeVisible(this.startFlagButton);
    }

    async isTurboModeEnabled(): Promise<boolean> {
        return await this.isElementVisible(this.turboModeLable, "Element is not visible")
    }

    async closeTutorialVideo(): Promise<void> {
        await this.clickOnElement(this.closeTutorialVideoBtn);
    }

    async moveCodeBlock(): Promise<void> {
        await this.dragAndDrop(this.blockOfCode, this.constructorArea)
    }

    async waitForBlockInConstructArea(): Promise<void> {
        await this.elementShouldBeVisible(this.blockOfCodeInConstructorArea);
    }

    async isBlockInDropArea(): Promise<boolean> {
        return await this.isElementVisible(this.blockOfCodeInConstructorArea, "Block is not verified in dropped area");
    }

    async openSettingsDropDown(): Promise<void> {
        await this.clickOnElement(this.settingsButton);
    }

    async openEditDropDown(): Promise<void> {
        await this.clickOnElement(this.editButton);
    }

    async selectSettingsSubMenu(index: number): Promise<void> {
        const button: Locator = await this.getSettingsSubMenusByIndex(index);
        await button.click();
    }

    async getSettingsSubMenusByIndex(index: number): Promise<Locator> {
        return this.findLocator(`//div[@class='menu-bar_menu-bar-menu_239MD']/ul[@class='menu_menu_3k7QT menu_right_3PQ4S']/li[${index}]`);
    }

    async selectEditSubMenu(index: number): Promise<void> {
        const button: Locator = await this.getEditSubMenusByIndex(index);
        await button.click();
    }

    async getEditSubMenusByIndex(index: number): Promise<Locator> {
        return this.findLocator(`//li[${index}][contains(@class, 'menu_hoverable_3u9dt')]`);
    }

    async selectLanguage(language: string): Promise<void> {
        const selectedLanguage = this.findLocator(this.languages).getByText(language);
        await selectedLanguage.click();
    }

    async getSettingTitle(): Promise<string | null> {
        return await this.getTitle(this.settingsButton);
    }
}